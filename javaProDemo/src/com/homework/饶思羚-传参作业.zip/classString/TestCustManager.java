package com.homework.classString;

public class TestCustManager {

	public static void main(String[] args) {
		CustManager cus = new CustManager();
		cus.Mnue();

	}

}
