package com.homework.Object2;
/**
 * @author rsl
 * @功能 基础11
 * @时间 2017.5.27
 * */
public class MyDate {
	private String y;
	private String m;
	private String d;
	
	
	public MyDate() {
		super();
	}
	
	
	
	public MyDate(String y, String m, String d) {
		super();
		this.y = y;
		this.m = m;
		this.d = d;
	}



	public String getY() {
		return y;
	}
	public void setY(String y) {
		this.y = y;
	}
	public String getM() {
		return m;
	}
	public void setM(String m) {
		this.m = m;
	}
	public String getD() {
		return d;
	}
	public void setD(String d) {
		this.d = d;
	}
	
	
}
