package com.homework.classString;
/**
 * @功能 类的有参 上机练习5
 * @作者 饶思羚
 * @时间 2017.5.21
 * @地址 机房
 * */
public class Customer {
	int number = 0;//会员编号
	int vipintegral = 0;//会员积分
	//构造函数
	public Customer(){
		
	}
	public Customer(int number,int vipintegral){
		this.number = number;
		this.vipintegral = vipintegral;
	}
}
