package com.homework.Object2;
/**
 * @author rsl
 * @功能 基础10
 * @时间 2017.5.27
 * */
public class zuoye10 {
/**
 * 
 * 静态成员是当前类中共享内容
 * 而实例成员当进行实例化时 都会有一个自己的副本
 * 
 * */
}
