package com.homework.Object2;
/**
 * @author rsl
 * @功能 基础15
 * @时间 2017.5.26
 * */
public class Student2 {
	static String name;
}
