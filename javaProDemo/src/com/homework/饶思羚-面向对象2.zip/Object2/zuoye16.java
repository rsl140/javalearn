package com.homework.Object2;
/**
 * @author rsl
 * @功能 基础16
 * @时间 2017.5.26
 * */
public class zuoye16 {
	private String[] s;

	public String[] getS() {
		return s;
	}

	public void setS(String[] s) {
		this.s = s;
	}
	
}
