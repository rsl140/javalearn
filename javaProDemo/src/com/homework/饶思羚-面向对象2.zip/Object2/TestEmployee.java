package com.homework.Object2;

public class TestEmployee {

	public static void main(String[] args) {
		Employee test = new Employee("2017","05","25","xb","100000");
		test.show();
	}

}
