package com.homework.classString;

public class TestDaikuan {
	/**
	 * @功能 课后练习1
	 * @作者 饶思羚
	 * @时间 2017.5.23
	 * @地址 机房
	 * */
	public static void main(String[] args) {
		Daikuan dk = new Daikuan();
		dk.Mnue();

	}

}
