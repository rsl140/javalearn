package com.homework.Object2;
/**
 * @author rsl
 * @功能 基础4
 * @时间 2017.5.27
 * */
public interface Moveable {
	public void Moveable();
}