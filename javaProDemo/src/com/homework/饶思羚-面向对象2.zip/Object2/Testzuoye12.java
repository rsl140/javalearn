package com.homework.Object2;

public class Testzuoye12 {

	public static void main(String[] args) {
		Jiaoyuan jy = new Jiaoyuan();
		zuoye12 zy = new zuoye12();
	}

}
