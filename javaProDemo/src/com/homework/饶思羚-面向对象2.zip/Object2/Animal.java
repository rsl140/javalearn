package com.homework.Object2;
/**
 * @author rsl
 * @功能 基础6
 * @时间 2017.5.27
 * */
public class Animal {
	public String name;
	public String width;//重量
	public String size;//大小
	
	public void run(){
		System.out.println("正在跑");
	}
	public void jump(){
		System.out.println("正在跳");
	}
	public void go(){
		System.out.println("正在走");
	}
}
