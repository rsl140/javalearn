package com.homework.classString;

public class TestFindTall {
	public static void main(String[] array){
		FindTall f = new FindTall();
		System.out.println(f.height());
	}
}
