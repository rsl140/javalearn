package com.homework.Object2;
/**
 * @author rsl
 * @功能 基础作业2
 * @时间 2017.5.25
 * */
public class Student1 {
	private int classNo;
	private String name;
	private int score;
	public int getClassNo() {
		return classNo;
	}
	public void setClassNo(int classNo) {
		this.classNo = classNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	
	
}
