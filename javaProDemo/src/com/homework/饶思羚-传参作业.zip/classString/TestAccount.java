package com.homework.classString;

public class TestAccount {

	public static void main(String[] args) {
		Account money = new Account();
		money.Mnue();

	}

}
